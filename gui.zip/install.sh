#!/bin/bash
# RijanOS Assistant - Installation Script
# Script instalasi otomatis untuk RijanOS Assistant
# Compatible with both sh and bash

set -e  # Exit on any error

echo "🚀 RijanOS Assistant - Installation Script"
echo "=============================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    print_error "Jangan jalankan script ini sebagai root!"
    print_warning "Jalankan sebagai user biasa, script akan meminta sudo jika diperlukan."
    exit 1
fi

# Check if running on Rijan OS or Ubuntu
if ! command -v apt &> /dev/null; then
    print_error "Script ini hanya untuk sistem berbasis Debian/Ubuntu!"
    exit 1
fi

print_header "1. Update sistem..."
sudo apt update && sudo apt upgrade -y

print_header "2. Install dependencies..."
sudo apt install -y python3 python3-pip python3-venv git python3-pyqt6 python3-pyqt6.qtwidgets

print_header "3. Install Python packages..."
pip3 install requests httpx

print_header "4. Create application directory..."
sudo mkdir -p /opt/rijanos-assistant
sudo chown -R $USER:$USER /opt/rijanos-assistant

print_header "5. Copy application files..."
if [ -d "/opt/rijanos-assistant" ]; then
    # Copy current directory contents to /opt/rijanos-assistant
    cp -r . /opt/rijanos-assistant/
    cd /opt/rijanos-assistant
else
    print_error "Direktori /opt/rijanos-assistant tidak ditemukan!"
    exit 1
fi

print_header "6. Set permissions..."
chmod +x /opt/rijanos-assistant/main.py
chmod +x /opt/rijanos-assistant/demo.py
chmod +x /opt/rijanos-assistant/install.sh
chmod +x /opt/rijanos-assistant/uninstall.sh

print_header "7. Create config.json if not exists..."
if [ ! -f "/opt/rijanos-assistant/config.json" ]; then
    print_status "Membuat config.json default..."
    # Config will be created on first run
fi

print_header "8. Setup autostart (opsional)..."
printf "Apakah Anda ingin RijanOS Assistant berjalan otomatis saat login? (y/n): "
read -r REPLY
if [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]; then
    mkdir -p ~/.config/autostart
    cp rijanos-assistant.desktop ~/.config/autostart/
    chmod +x ~/.config/autostart/rijanos-assistant.desktop
    print_status "Autostart berhasil dikonfigurasi!"
else
    print_warning "Autostart tidak dikonfigurasi. Anda dapat mengaturnya nanti."
fi

print_header "9. Test installation..."
cd /opt/rijanos-assistant
python3 demo.py

print_header "10. Installation completed!"
echo "=============================================="
print_status "RijanOS Assistant berhasil diinstal!"
print_status "Lokasi: /opt/rijanos-assistant"
print_status "Jalankan dengan: python3 /opt/rijanos-assistant/main.py"

echo
print_status "Fitur yang tersedia:"
echo "  🤖 AI Assistant (konfigurasi di Settings)"
echo "  📦 Package Manager"
echo "  🎬 Multimedia Apps"
echo "  💾 Backup & Restore"
echo "  ⚡ Power Management"
echo "  🔔 System Tray"

echo
print_status "Dokumentasi lengkap: /opt/rijanos-assistant/DOCUMENTATION.md"
print_status "Bug report: https://github.com/teguh02/rijan_os/issues"

echo
printf "Apakah Anda ingin menjalankan RijanOS Assistant sekarang? (y/n): "
read -r REPLY
if [ "$REPLY" = "y" ] || [ "$REPLY" = "Y" ]; then
    print_status "Menjalankan RijanOS Assistant..."
    python3 /opt/rijanos-assistant/main.py
fi

echo
print_status "Terima kasih telah menggunakan RijanOS Assistant!"
